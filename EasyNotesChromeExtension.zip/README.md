# EasyNotes Chrome Extension
Description: Have you ever had issues with trying to write something quickly but can't find a piece of paper around you? Now it's no longer a problem, use our EasyNotes app and it allows you to have access to 3 save files and 3 load files to keep track of your most important thoughts so that you don't have to worry about being interrupted by other things. The application is designed with a mindset of userfriendly and comes with an easy guide on how to use that is very easy to follow. More updates for more features may come in the future.

EasyNotes
User manual:
Overview
The purpose of this app is used to create a place for user to have a space to quickly draw down any notes and information that they need to save. To use the app it's very simple, whenever you write something the app will allow you to save in 3 different slots. The three slots allows you to retrieve and store information with the corresponding buttons for save and load.

How to use save
Choose the slot that you like to save in; for example below we want to save in slot1. After input the text and title, click save1 button

Save Instructions:
How to use Load
Choose the slot that you like to load with; In the example below we want to load what we saved in slot1, click the button load 1

Load Instructions:
Links:
Click here to access to our github repository.
Click here to access to our design and blogs for the development.
Developed by Guan Li and Xiao Xia:
